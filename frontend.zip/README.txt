Frontend deployment instructions:
1. Upload to Vercel
2. Set env var NEXT_PUBLIC_BACKEND_URL
